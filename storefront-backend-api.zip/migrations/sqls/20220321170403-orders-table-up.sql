CREATE TABLE orders (
    ID SERIAL PRIMARY KEY, 
    user_id bigint REFERENCES users(id), 
    status VARCHAR(255)
);